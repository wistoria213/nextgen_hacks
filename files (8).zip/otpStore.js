// lib/otpStore.js
//
// WHY THIS FILE EXISTS:
// Vercel serverless functions are stateless — a variable set in
// send-otp.js does NOT survive into the next invocation of verify-otp.js
// (they may not even run on the same machine). So the OTP can't live in
// a JS variable; it needs an external store. We use Vercel KV (which is
// Upstash Redis under the hood) because it's a one-click add-on in the
// Vercel dashboard and needs zero extra infra.
//
// Setup (one-time):
//   1. Vercel dashboard → your project → Storage tab → Create Database → KV
//   2. Connect it to this project. Vercel auto-injects KV_REST_API_URL and
//      KV_REST_API_TOKEN as environment variables — you don't set those
//      yourself.
//   3. npm install @vercel/kv

import { kv } from '@vercel/kv';

const OTP_TTL_SECONDS = 120; // matches the 2:00 timer in the frontend

export async function storeOTP(phone, code) {
  await kv.set(`otp:${phone}`, code, { ex: OTP_TTL_SECONDS });
}

export async function getOTP(phone) {
  return await kv.get(`otp:${phone}`);
}

export async function deleteOTP(phone) {
  await kv.del(`otp:${phone}`);
}

// Basic rate limiting so one phone number can't be used to spam OTPs
// or brute-force a code. Tracks attempts in a separate KV key.
export async function checkRateLimit(phone, maxAttempts = 5, windowSeconds = 600) {
  const key = `otp_attempts:${phone}`;
  const attempts = await kv.incr(key);
  if (attempts === 1) {
    await kv.expire(key, windowSeconds);
  }
  return attempts <= maxAttempts;
}
