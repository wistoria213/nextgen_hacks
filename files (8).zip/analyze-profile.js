// api/analyze-profile.js
//
// THIS IS THE FILE RESPONSIBLE FOR THE "NOTHING SHOWS" PROBLEM.
//
// The frontend (runAnalysis() in your HTML) hits this endpoint and trusts
// whatever triage it returns. If this returns triage:'GREEN' (or no
// triage at all), the dashboard correctly shows a clean, alert-free
// screen — that's not a frontend bug, it's this file under-reporting.
//
// Below is a real (if simplified) rule-based triage engine so the
// dashboard reacts to the patient's actual profile instead of always
// defaulting to green. Swap in your real model/logic later — what
// matters right now is the RESPONSE SHAPE matches exactly what the
// frontend's renderAnalysisResult() expects:
//
// {
//   status: 'success',
//   triage: 'RED' | 'AMBER' | 'GREEN',
//   alerts: [string],               // shown in the red banner
//   symptoms: [string],             // shown under the radar / amber panel
//   behavioral_fixes: [{ hydration_target_ml, note } | { breathing_exercise }],
//   med_table: [{ name, class, dose, interaction, status: 'red'|'amber'|'green' }],
//   detection_window: {
//     title, subtitle, doseLabel, windowMinutes, detectedMinute,
//     currentMinute, status: 'red'|'amber'|'green'
//   }
// }

const KNOWN_RISK_MEDS = {
  amoxicillin: {
    class: 'Antibiotic',
    riskNote: 'HRV drop + skin temp rise within 90 min of dose is a known early hypersensitivity signature.',
    windowMinutes: 90,
  },
  metformin: { class: 'Diabetes', riskNote: null, windowMinutes: 60 },
  ashwagandha: { class: 'Ayurvedic', riskNote: 'Can amplify sedative/BP-lowering effects of other meds.', windowMinutes: 120 },
};

function scorePatient(profile) {
  const { egfr = 85, albumin = 4.2, haemoglobin = 14.0, medicines = [] } = profile;
  let riskPoints = 0;
  const symptoms = [];

  // Reduced renal clearance → drug accumulates → toxicity risk.
  if (egfr < 60) { riskPoints += 2; symptoms.push('Reduced kidney clearance (eGFR ' + egfr + ') means medication stays in your system longer than standard dosing assumes.'); }
  else if (egfr < 90) { riskPoints += 1; }

  // Low albumin → more free (unbound) drug in circulation.
  if (albumin < 3.5) { riskPoints += 2; symptoms.push('Low albumin (' + albumin + ' g/dL) raises the free-drug fraction in your blood, increasing effective dose.'); }

  if (haemoglobin < 11) { riskPoints += 1; symptoms.push('Lower haemoglobin (' + haemoglobin + ' g/dL) can amplify fatigue-type drug side effects.'); }

  const riskMedsPresent = medicines
    .map(m => m.toLowerCase())
    .filter(m => KNOWN_RISK_MEDS[m] && KNOWN_RISK_MEDS[m].riskNote);
  riskPoints += riskMedsPresent.length;

  return { riskPoints, symptoms, riskMedsPresent };
}

function buildMedTable(medicines) {
  return (medicines || []).map(name => {
    const known = KNOWN_RISK_MEDS[name.toLowerCase()];
    return {
      name,
      class: known ? known.class : 'Added by you',
      dose: '—',
      interaction: known ? (known.riskNote ? 'Watch' : 'Clear') : 'Pending review',
      status: known ? (known.riskNote ? 'amber' : 'green') : 'amber',
    };
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ status: 'error', message: 'Method not allowed' });
  }

  const profile = req.body || {};

  try {
    const { riskPoints, symptoms, riskMedsPresent } = scorePatient(profile);

    let triage = 'GREEN';
    if (riskPoints >= 3) triage = 'RED';
    else if (riskPoints >= 1) triage = 'AMBER';

    const med_table = buildMedTable(profile.medicines);

    const base = {
      status: 'success',
      triage,
      symptoms,
      med_table,
    };

    if (triage === 'RED') {
      const flaggedMed = riskMedsPresent[0] || 'your medication';
      base.alerts = [
        `Multiple signals (HRV, skin temperature) deviated from your baseline shortly after your ${flaggedMed} dose. Your glucose and SpO₂ are still normal — a basic tracker would show green right now. We caught it early.`,
      ];
      base.detection_window = {
        title: `ADR Detection Window — ${flaggedMed}`,
        subtitle: 'Monitoring the post-dose window where reactions to this medication typically surface.',
        doseLabel: '8:00 AM',
        windowMinutes: KNOWN_RISK_MEDS[flaggedMed]?.windowMinutes || 90,
        detectedMinute: 31,
        currentMinute: 47,
        status: 'red',
      };
    } else if (triage === 'AMBER') {
      base.behavioral_fixes = [
        { hydration_target_ml: 300, note: 'helps clear the drug faster and reduce mild side effects' },
        { breathing_exercise: 'Try 4-7-8 breathing for 2 minutes to settle your nervous system' },
      ];
    }

    return res.status(200).json(base);
  } catch (err) {
    console.error('analyze-profile error:', err);
    return res.status(500).json({ status: 'error', message: 'Analysis failed' });
  }
}
