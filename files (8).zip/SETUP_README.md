# RxGuard — Backend Setup & Deployment (Vercel)

This covers: why the dashboard stopped showing the red alert, and exactly
how to deploy the OTP + analysis backend.

## 1. File placement

Drop these into your existing Vercel project like this:

```
your-project/
├── index.html          ← your existing frontend (unchanged)
├── api/
│   ├── analyze-profile.js
│   ├── send-otp.js
│   └── verify-otp.js
├── lib/
│   └── otpStore.js
├── package.json
└── vercel.json          (only needed if index.html isn't already your root)
```

Vercel auto-detects any file inside `/api` as a serverless function —
`api/send-otp.js` is automatically served at `/api/send-otp`. That's why
the frontend's `fetch('/api/send-otp')` works with zero extra routing
config, as long as the file is in the right place.

## 2. Install dependencies

```bash
npm install @vercel/kv
```

(No need to install Express or anything — these are plain Vercel
serverless functions, not a server you run yourself.)

## 3. Set up storage for OTPs (required)

Serverless functions don't share memory between requests, so the OTP
can't live in a normal JS variable — it has to be in a place every
invocation can read from. Vercel KV (Upstash Redis) does this with no
separate account needed:

1. Vercel dashboard → your project → **Storage** tab → **Create Database** → **KV**
2. Click **Connect** to link it to this project
3. Vercel automatically adds `KV_REST_API_URL` and `KV_REST_API_TOKEN` to
   your project's environment variables — you don't type these in yourself

## 4. Set up MSG91 for actual SMS sending

1. Sign up at https://msg91.com
2. Complete **DLT registration** for your sender ID — mandatory for any
   SMS to Indian numbers, not an MSG91-specific hurdle. Their dashboard
   walks you through it; approval is usually same-day.
3. Create an **OTP template** (Campaigns → OTP) containing the literal
   placeholder `##OTP##`, e.g.:
   > Your RxGuard verification code is ##OTP##. Valid for 2 minutes.
4. Grab your **Auth Key** (API section) and the **Template ID** you just created.

In Vercel dashboard → Settings → Environment Variables, add:

| Key | Value |
|---|---|
| `MSG91_AUTH_KEY` | from MSG91 dashboard |
| `MSG91_TEMPLATE_ID` | the OTP template ID you created |

Never put these in the HTML/JS — anything in frontend code is visible to
anyone via DevTools.

## 5. Why the red alert disappeared (and how it's fixed now)

Your dashboard calls `/api/analyze-profile` and only shows the red
banner / ADR detection window when the response says `triage: "RED"`.
If that endpoint didn't exist yet, or returned something without a
proper triage field, the dashboard correctly shows a clean screen
instead of faking danger — that was working as designed, just with an
under-powered backend.

The included `api/analyze-profile.js` is a real (if simplified)
rule-based engine: it scores eGFR, albumin, haemoglobin, and known
risk medicines (Amoxicillin, Ashwagandha, etc.) and returns RED / AMBER
/ GREEN accordingly, in the exact response shape your frontend expects.
Swap in your real clinical logic later — keep the response shape the same.

To test it shows RED again: in onboarding/profile, add "Amoxicillin" to
medicines, or set eGFR below 60 and albumin below 3.5 — `analyze-profile`
will score that as high-risk and the dashboard will show the alert.

## 6. Deploy

If your project is already connected to a GitHub repo:

```bash
git add api lib package.json
git commit -m "Add OTP + analysis backend"
git push
```

Vercel auto-deploys on push. Otherwise, from the project root:

```bash
npm install -g vercel   # one-time
vercel login
vercel --prod
```

## 7. Verify after deploy

- Open your deployed URL → sign up flow → enter a real phone number →
  you should receive a real SMS within seconds.
- On the dashboard, click "↻ Re-check Now" — `● LIVE` should stay (not
  flip to `● DEMO MODE`), confirming `/api/analyze-profile` is reachable.
