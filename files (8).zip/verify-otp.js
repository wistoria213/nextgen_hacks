// api/verify-otp.js
//
// Reached at /api/verify-otp by the frontend's verifyOTP() function.
// The correct code lives only in KV (set by send-otp.js) — never in the
// frontend — so there's nothing for someone to read out of DevTools.

import { getOTP, deleteOTP } from '../lib/otpStore.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ status: 'error', message: 'Method not allowed' });
  }

  const { phone, code } = req.body || {};
  if (!phone || !code) {
    return res.status(400).json({ status: 'error', message: 'Missing phone or code' });
  }

  try {
    const storedCode = await getOTP(phone);

    if (!storedCode) {
      return res.status(400).json({ status: 'error', message: 'OTP expired or not found. Request a new one.' });
    }

    if (storedCode !== code) {
      return res.status(400).json({ status: 'error', message: 'Incorrect OTP' });
    }

    await deleteOTP(phone); // one-time use
    return res.status(200).json({ status: 'success' });
  } catch (err) {
    console.error('verify-otp error:', err);
    return res.status(502).json({ status: 'error', message: 'Could not verify right now' });
  }
}
