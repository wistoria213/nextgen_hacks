// api/send-otp.js
//
// Vercel auto-detects any file in /api as a serverless function reachable
// at /api/<filename>. So this file living at api/send-otp.js is exactly
// what the frontend's fetch('/api/send-otp') hits in production.
//
// Required environment variables (set in Vercel dashboard → Settings →
// Environment Variables — never put these in the frontend code):
//   MSG91_AUTH_KEY     — from MSG91 dashboard → API → Auth Key
//   MSG91_TEMPLATE_ID  — the DLT-approved OTP template ID (see notes below)
//
// MSG91 setup (one-time, takes ~15–30 min including DLT approval):
//   1. Sign up at https://msg91.com
//   2. Complete DLT registration for your sender ID (mandatory for India
//      SMS — MSG91's dashboard walks you through this, usually approved
//      within a few hours).
//   3. Create an OTP template under Campaigns → OTP. It must contain the
//      literal placeholder ##OTP## somewhere, e.g.:
//      "Your RxGuard verification code is ##OTP##. Valid for 2 minutes."
//   4. Copy that template's ID into MSG91_TEMPLATE_ID.
//   5. Copy your Auth Key into MSG91_AUTH_KEY.

import { storeOTP, checkRateLimit } from '../lib/otpStore.js';

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6 digits
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ status: 'error', message: 'Method not allowed' });
  }

  const { phone } = req.body || {};
  if (!phone || !/^\+91\d{10}$/.test(phone)) {
    return res.status(400).json({ status: 'error', message: 'Invalid phone number' });
  }

  const allowed = await checkRateLimit(phone);
  if (!allowed) {
    return res.status(429).json({ status: 'error', message: 'Too many OTP requests. Try again later.' });
  }

  const code = generateOTP();

  try {
    const msg91Res = await fetch('https://control.msg91.com/api/v5/otp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        authkey: process.env.MSG91_AUTH_KEY,
      },
      body: JSON.stringify({
        template_id: process.env.MSG91_TEMPLATE_ID,
        mobile: phone.replace('+', ''), // MSG91 expects e.g. 919876543210
        otp: code,
        otp_expiry: 2, // minutes
      }),
    });

    const msg91Data = await msg91Res.json();
    if (msg91Data.type !== 'success') {
      throw new Error(msg91Data.message || 'MSG91 send failed');
    }

    await storeOTP(phone, code);
    return res.status(200).json({ status: 'success' });
  } catch (err) {
    console.error('send-otp error:', err);
    return res.status(502).json({ status: 'error', message: 'Could not send OTP right now' });
  }
}
